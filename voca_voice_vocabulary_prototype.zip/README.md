# Voca — Voice Vocabulary Coach

A single-page vocabulary practice prototype with six words, text-to-speech, browser voice input, typed fallback, feedback, and progress tracking.

## Run
Open `index.html`. For microphone recognition, use Chrome or Edge on HTTPS or localhost and grant microphone permission. Browser support varies.

## Publish a shareable URL free with GitHub Pages
1. Create a public GitHub repository (for example, `voca-vocabulary-coach`).
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. Share the published URL shown there (typically `https://YOUR-USERNAME.github.io/voca-vocabulary-coach/`).

Note: the prototype's feedback is rule-based, not a live AI model. Speech is processed by browser speech APIs; this prototype does not send sentences to a custom server.
